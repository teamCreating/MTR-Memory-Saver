from pathlib import Path
import json, zipfile, hashlib, subprocess, time
root=Path.cwd()
out=root/".cache/acceptance/snapshot-055"
plan=json.loads((out/"client/packaged-client-plan.json").read_bytes())
best=None
for pack in (out/"client/resourcepacks").glob("*.zip"):
 with zipfile.ZipFile(pack) as z:
  for entry in z.infolist():
   if entry.filename.endswith(".bbmodel") and (best is None or entry.file_size>best[0]):
    best=(entry.file_size,pack,entry.filename)
with zipfile.ZipFile(best[1]) as z: raw=z.read(best[2])
(out/"input.bbmodel").write_bytes(raw)
expected=hashlib.sha256(raw.decode("utf-8",errors="replace").encode("utf-8")).hexdigest()
source=r"""package site.benli06;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.lang.management.ManagementFactory;
public final class SnapshotBenchmark {
 public static void main(String[] args) throws Exception {
  var path=Path.of(args[0]);
  var admission=new ReadAdmission(1,100000000);
  var cpu=ManagementFactory.getThreadMXBean();
  String answer="";
  for(int pass=0;pass<2;pass++) {
   long start=System.nanoTime(), startCpu=cpu.getCurrentThreadCpuTime();
   for(int i=0;i<3;i++) {
    try(var input=Files.newInputStream(path);
        var snapshot=ResourceTextSnapshot.capture(input,StandardCharsets.UTF_8,admission);
        var reader=snapshot.reader()) {
      answer=snapshot.digest();
      if(!answer.equals(ResourceTextDigest.sha256(reader))) throw new AssertionError("Snapshot mismatch");
    }
   }
   long elapsed=System.nanoTime()-start, usedCpu=cpu.getCurrentThreadCpuTime()-startCpu;
   if(pass==1) System.out.println("{\"elapsed_ns\":"+elapsed+",\"thread_cpu_ns\":"+usedCpu+",\"digest\":\""+answer+"\"}");
  }
 }
}"""
(out/"SnapshotBenchmark.java").write_text(source,encoding="utf-8")
java=Path(plan["java"])
commons=next((out/"client/libraries/commons-io/commons-io").rglob("*.jar"))
candidate=out/"candidate.jar"
baseline=root/"evidence/engineering-051/streamed-obj-input/runs/02-final-nf248/mtr-memory-saver-official-nf248-0.4.8.jar"
classes=out/"benchmark-classes";classes.mkdir()
cp=str(candidate)+";"+str(commons)
subprocess.run([str(java.with_name("javac.exe")),"--release","21","-cp",cp,"-d",str(classes),str(out/"SnapshotBenchmark.java")],check=True)
f=lambda p:{"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
frozen={"baseline":f(baseline),"candidate":f(candidate),"input":f(out/"input.bbmodel"),
        "member":best[2],"archive":f(best[1]),"expected":expected,"pairs":6,"iterations":3,
        "primary":"thread_cpu_ns","timing_context":"Shared workstation. Fresh JVM, one warmup batch, balanced AB/BA. Source snapshot capture/read only."}
(out/"benchmark-plan.json").write_text(json.dumps(frozen,indent=2),encoding="utf-8")
results=[]
for pair in range(6):
 for role in (["baseline","candidate"] if pair%2==0 else ["candidate","baseline"]):
  artifact={"baseline":baseline,"candidate":candidate}[role]
  argv=[str(java),"-Xms64m","-Xmx256m","-cp",str(classes)+";"+str(artifact)+";"+str(commons),"site.benli06.SnapshotBenchmark",str(out/"input.bbmodel")]
  start=time.time(); result=subprocess.run(argv,capture_output=True,timeout=180)
  (out/f"benchmark-{pair}-{role}.stdout.log").write_bytes(result.stdout)
  (out/f"benchmark-{pair}-{role}.stderr.log").write_bytes(result.stderr)
  record={"pair":pair,"role":role,"argv":argv,"exit":result.returncode,"started_unix":start,"finished_unix":time.time()}
  if result.returncode==0: record["metrics"]=json.loads(result.stdout)
  results.append(record)
  (out/"benchmark-results.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
  print(pair,role,result.returncode,flush=True)
  if result.returncode or record["metrics"]["digest"]!=expected: raise RuntimeError(record)
