package site.benli06;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.lang.management.ManagementFactory;
public final class SnapshotBenchmark {
 public static void main(String[] args) throws Exception {
  var path=Path.of(args[0]);
  var admission=new ReadAdmission(1,100000000);
  var cpu=ManagementFactory.getThreadMXBean();
  String answer="";
  for(int pass=0;pass<2;pass++) {
   long start=System.nanoTime(), startCpu=cpu.getCurrentThreadCpuTime();
   for(int i=0;i<3;i++) {
    try(var input=Files.newInputStream(path);
        var snapshot=ResourceTextSnapshot.capture(input,StandardCharsets.UTF_8,admission);
        var reader=snapshot.reader()) {
      answer=snapshot.digest();
      if(!answer.equals(ResourceTextDigest.sha256(reader))) throw new AssertionError("Snapshot mismatch");
    }
   }
   long elapsed=System.nanoTime()-start, usedCpu=cpu.getCurrentThreadCpuTime()-startCpu;
   if(pass==1) System.out.println("{\"elapsed_ns\":"+elapsed+",\"thread_cpu_ns\":"+usedCpu+",\"digest\":\""+answer+"\"}");
  }
 }
}